export interface Art {
  id: number,
  description: string,
  title: string,
  body: string,
  price: number,
  img: string
}
